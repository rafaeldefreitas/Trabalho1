/*
Experimento 1
Resposta 6: Botão voltar para e destrói aplicação e botão inicio para e pausa a aplicação.
Experimento 2
Resposta 3: O progresso seria perdido e a aplicação seria reiniciada.
*/
package com.example.rafaelfreitas.experimento1e2;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Log.i("MainActivity", "onCreate()");
    }

    @Override
    protected void onStart() {
        super.onStart();
        Log.e("MainActivity", "OnStart()");
    }

    @Override
    protected void onResume() {
        super.onResume();
        Log.d("MainActivity", "onResume()");
    }

    @Override
    protected void onPause() {
        super.onPause();
        Log.i("MainActivity", "onPause()");
    }

    @Override
    protected void onStop() {
        super.onStop();
        Log.v("MainActivity", "onStop()");
    }

    @Override
    protected void onRestart() {
        super.onRestart();
        Log.w("MainActivity", "onRestart()");
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        Log.d("MainActivity", "onDestroy()");
    }

}
